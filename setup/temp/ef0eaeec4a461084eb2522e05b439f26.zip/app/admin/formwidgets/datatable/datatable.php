<div
    id="<?= $dataTableId ?>"
    class="field-datatable size-<?= $size ?>">

    <?= $table->render() ?>

</div>

