<?php foreach ($widget->getFields() as $field) { ?>
    <?= $widget->renderField($field) ?>
<?php } ?>
