subject = "Password reset at {site_name}"
==

Hi, {staff_name}

Your password was changed successfully!

If you think this password update was a mistake, reset your password immediately.

==

<!-- BODY -->
<table class="body-wrap">
    <tr>
        <td></td>
        <td class="container" bgcolor="#FFFFFF">
            <div class="content">
                <table>
                    <tr>
                        <td>
                            <h3>Hi, {staff_name}</h3>
                            <p class="lead">Your password was changed successfully!</p>
                            <p>If you think this password update was a mistake, reset your password immediately.</p>
                        </td>
                    </tr>
                </table>
            </div><!-- /content -->
        </td>
        <td></td>
    </tr>
</table><!-- /BODY -->
