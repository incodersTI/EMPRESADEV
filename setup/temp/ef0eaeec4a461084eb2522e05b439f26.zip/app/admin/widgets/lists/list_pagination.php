<?php if ($showPagination) { ?>
    <nav class="pagination-bar clearfix">
        <?= $records->render(); ?>
    </nav>
<?php } ?>
