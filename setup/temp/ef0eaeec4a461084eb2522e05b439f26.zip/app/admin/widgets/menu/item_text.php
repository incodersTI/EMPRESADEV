<li class="nav-item">
    <span class="btn-location">
        <i class="fa fa-bank fa-fw visible-xs-inline-block"></i>
        <span class="text-nowrap hidden-xs"><strong><?= AdminAuth::getLocationName(); ?></strong></span>
    </span>
</li>
