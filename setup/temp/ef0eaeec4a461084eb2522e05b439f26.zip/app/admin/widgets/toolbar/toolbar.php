<div
    id="<?= $toolbarId ?>"
    class="toolbar btn-toolbar <?= $cssClasses ?><?= (!$this->showToolbar) ? ' hide' : '' ?>"
>
    <div class="toolbar-action">
        <?= $buttonsHtml; ?>
    </div>
</div>
