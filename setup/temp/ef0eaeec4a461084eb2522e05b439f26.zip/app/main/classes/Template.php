<?php

namespace Main\Classes;

class Template extends \Igniter\Flame\Pagic\Template
{
}