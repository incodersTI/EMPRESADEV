<?php

namespace Main\Template\Code;

use Igniter\Flame\Pagic\TemplateCode;

class LayoutCode extends TemplateCode
{
}