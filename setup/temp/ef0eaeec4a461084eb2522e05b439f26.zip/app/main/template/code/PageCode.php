<?php

namespace Main\Template\Code;

use Igniter\Flame\Pagic\TemplateCode;

class PageCode extends TemplateCode
{
}