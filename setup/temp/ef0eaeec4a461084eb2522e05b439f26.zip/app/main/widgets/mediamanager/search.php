<input
    type="text"
    class="form-control"
    value="<?= $searchTerm; ?>"
    placeholder="<?= lang('main::lang.media_manager.text_filter_search'); ?>"
    data-media-control="search"/>
