<div class="media-statusbar" role="navigation">
    <p class="statusbar-text">
        <span data-media-total-size>0</span>
        <span class="total-selected-text"> of </span>
        <?= sprintf(lang('main::lang.media_manager.text_footer_note'), $totalItems, $folderSize); ?>
    </p>
</div>
