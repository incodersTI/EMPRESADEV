<div class="media-uploader dropzone" data-control="media-upload" style="display: none;">
    <button type="button" class="close" data-media-control="close-uploader" aria-hidden="true">X</button>
</div>
